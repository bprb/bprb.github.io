-- example cfg file
-- Rename to ponsole_cfg.lua in either user folder root or current launch folder.
--
-- None of these settings can be changed after startup.
--
-- Note you can override these with folder-local cfg files and/or scripts passed with -c
-- See:
-- 1.   ponsole.exe -?
-- 2.   help ''              (in the dropdown, ctrl-shift-tilde)
--
-- In theory you can plaster your desktop with a nicely tiled setup of multiple consoles,
-- each sized and positioned just right, and configured with different colors, keybindings,
-- default shell, and scripts.  In theory.

config = {
	-- in pixels, used as-is (no DPI adjustments);
	-- zero width or height means "full desktop work area"
	-- (= entire primary monitor, minus non-hidden taskbar)
	output_width  = 1920,
	output_height = 1080,
	win_posx      = 300,
	win_posy      = 100,

	-- the default is 'cmd.exe'
	--cmd = 'nu',
	--cmd = 'powershell',

	-- HDR scaling factor for the cursor and drop down cursor.
	-- (the colors set via terminal.set_tab_colors are SDR)
	hdr_cursor_scale          = 4,
	hdr_dropdown_cursor_scale = 4,

	-- intensity scale when window is inactive (alt-tab)
	inactive_scale = 0.5, -- the default, 50% dim
	
	-- set to zero to disable left-drag moving the window
	enable_mouse_move = 1


	-- the budget is 15 fonts or less for all fonts plus style_fonts.
	--
	-- This list of fonts serves two purposes.
	--
	-- 1. It is searched in-order until a font contains a glyph.
	--
	--    For instance you start with a nerdfont, but then also want to print
	--    Korean, so you add a Korean font.
	--
	--    Note: the code automatically adds <system>/consola.ttf so there
	--    is always a reasonable glyph set, even if this list is empty.
	--
	--    A missing glyph will show up as a little diamond square.
	--
	--
	-- 2. Certain highlight colors can point at a certain font.
	--
	--    For instance, after nerdfont and Korean font you can add another
	--    font, say Arial, and then force `hi guifg=#89898c` to use it
	--    with this line in ponsole_run.lua:
	--
	--    terminal.set_tab_color_font(0, true, hex_color(0x89/255, 0x89/255, 0x8c/255), 2)
	--
	--    see ›help 'terminal.set_tab_color_font'
	--    In this case:
	--       0     = configure the current terminal (the current tab)
	--       true  = check the foreground color, not the background
	--       hex...= rendering-engineer-speak for 'rgb color #89898c'
	--       2     = use font 2  (ie. 3rd font, zero based counting)
	--
	--    Note: the index is really a starting point for the search. If font 2
	--    doesn't have a glyph, we'll go down the list, same as if we started at 0
	--    (and didn't find a glyph in font 0 nor font 1).
	--
	fonts = {
		-- there are two ways to specify a font.  The first is a string path:
		"~/SauceCodeBpe-Regular.ttf",

		-- the second is a table with:
		--   the string path
		--   a relative scaling factor (default: 1.0)
		--   a bool indicating if this is a monospace font (default: true);
		--          non-monospace glyphs are horizontally centered
		--          in their cell
		{ "~/Downloads/LibertinusMono-Regular.ttf", 0.9 },
	},
	-- in pixels, used as-is (no DPI adjustments)
	font_size = 25,

	-- style fonts replace font #0 when italic, bold, or both are active.
	-- if they don't contain the needed glyph, we go down the regular font
	-- list (starting at font #0).
	-- Order:
	--    italic
	--    bold
	--    italic bold
	--
	-- They can't be nil, so if you want bold but nothing else, copy font #0
	-- here.
	--
	-- The size is always the same as font_size, however you can use the table
	-- syntax to tweak scaling.
	style_fonts = {
		"~/Downloads/SauceCodeProNerdFontMono-Italic.ttf",
		"~/Downloads/SauceCodeProNerdFontMono-SemiBold.ttf",
		"~/Downloads/SauceCodeProNerdFontMono-SemiBoldItalic.ttf",
	},


	-- Fonts used by the dropdown (ctrl-shift-tilde).
	-- Searched in this order for glyphs.
	dropdown_fonts = {
		"~/Downloads/Terminus/TerminessNerdFontMono-Regular.ttf",
	},
	dropdown_font_size = 23,
}
