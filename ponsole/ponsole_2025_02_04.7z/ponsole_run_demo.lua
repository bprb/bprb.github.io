-- example post-launch script
-- Rename to ponsole_run.lua, or just dofile 'ponsole_run' (no extension needed)

-- remember the IDs of the current tab as 'vimtab'..
vim_tab   = terminal.get_tab()
-- .. and open a new one
build_tab = terminal.new_tab()


---- Tab styling ------------------------

-- change the colors of the build tab to green'ish
terminal.set_tab_colors(
			build_tab,
			0x002000,
			0x004000)

-- set default (VT 'reset') foreground color
terminal.set_default_colors(build_tab, 0x20e020)


-- ... and set_dropdown_colors for the Quake style dropdown


---- Automating keypresses ------------------------

-- send keys to a tab (which is running cmd.exe by default);
-- the tab does not need to be the visible.  \r is lua for 'press enter'
terminal.send(build_tab,
			  'prompt $T$S$G$S\r' ..
			  'cd projects/something\r' ..
			  'cls\r')


---- Key mapping ------------------------

-- key binding example: when pressing Ctrl-Shift-B in any
-- tab, do :wa in the vim tab, and start a build after 2 seconds
-- in the build tab.
terminal.map_key("<C-S-b>", function()
		-- save all..
		terminal.send(vim_tab, ":wa\r")
		-- .. and 'fix' race condition with a sleep, then build
		terminal.send(build_tab, 'timeout /t 2 /nobreak > NUL & b.bat\r')
	end )


---- Output rewriting (conceal) ------------------------

-- text filtering example: replace 'uint8_t' with 'u8'
-- (unless the cursor is on the same line).
-- In this example, use the default "conceal" colors that
-- just so happen to match my vimrc :high Conceal.
terminal.add_conceal(vim_tab, 'uint8_t' , 'u8' )

-- text filtering example: keep the text, but change
-- the colors, to make LOG and ERR pop more.
-- Note: these colors are SDR for now.
terminal.add_conceal(build_tab, 'LOG', 'LOG', 0xB0B000)

-- get fancy. double wide characters are supported.
-- Note: conceal stops at the first match.
terminal.add_conceal(build_tab, 'ERR', '  ', 0xFF0000)

-- example binding to toggle all filters so we can see ground truth
terminal.map_key('<C-S-f>', function()
	terminal.enable_conceal(0, not terminal.conceal_enabled())
end)


---- Changing fonts ------------------------

-- font changing example: comments use highlight guifg=0x89898c,
-- the next line is how you write "when the foreground uses this
-- color, use font 1" (ie. the second font in config.fonts)
terminal.set_tab_color_font(0, true, 0x89898c, 1)
-- same, but watch for a background color of 0x202040, and use font 3:
terminal.set_tab_color_font(0, false, 0x202040, 3)


---- HDR boosts ------------------------

-- The terminal is still SDR, so to get HDR, we use a sort-of palette:
-- like with fonts, if a color matches a key, then it's replaced wholesale
-- by new (HDR) R, G, B values.
--
-- For instance, with this vimrc...
--
--      highlight search guifg=0xffff80
--
-- ... the next line will render search results in HDR rgb(5, 5, 2.5), ie.
--     about 5 times brighter than normal SDR "white".
--     HDR (1,1,1) is automatically calibrated to match SDR pure white on the
--     brightest monitor.
terminal.set_tab_remap_color(0,               -- terminal ID, 0 == current
							true,             -- check if the foreground matches..
							0xffff80,          -- .. this color,
							{ 5, 5, 2.5, 1 }  -- if so use this as foreground color
							)   -- optional 5th param changes background color



-- launch vim
terminal.send(vim_tab, "nvim.exe -S workspace.vim\r")


-- change the background every 5 minutes
do
	local images = {
		'Pictures/wallpaper1.jpg',
		'Pictures/wallpaper2.png',
		'Pictures/wallpaper3.png',
	}
	local index = 1
	function set_wallpaper()
		terminal.set_tab_background_image(vim_tab, images[index])
		if index == #images then
			index = 1
		else
			index = index + 1
		end
		terminal.set_timer(5 * 60, set_wallpaper)
	end
	set_wallpaper()
end

