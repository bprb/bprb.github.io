-- example post-launch script
-- Rename to ponsole_run.lua, or just dofile 'ponsole_run' (no extension needed)

-- remember the IDs of the current tab as 'vimtab'..
vim_tab   = terminal.get_tab()
-- .. and open a new one
build_tab = terminal.new_tab()


---- Tab styling ------------------------

-- change the colors of the build tab to green'ish
terminal.set_tab_colors(
			build_tab,
			hex_color(0, 0.05, 0),
			hex_color(0, 0.10, 0))

-- ... and set_dropdown_colors for the Quake style dropdown


---- Automating keypresses ------------------------

-- send keys to a tab (which is running cmd.exe by default);
-- the tab does not need to be the visible.  \r is lua for 'press enter'
terminal.send('prompt $T$S$G$S\r' ..
			  'cd projects/something\r' ..
			  'cls\r',
			  build_tab)


---- Key mapping ------------------------

-- key binding example: when pressing Ctrl-Shift-B in any
-- tab, do :wa in the vim tab, and start a build after 2 seconds
-- in the build tab.
terminal.map_key("<C-S-b>", function()
		-- save all..
		terminal.send(":wa\r", vim_tab)
		-- .. and 'fix' race condition with a sleep, then build
		terminal.send('timeout /t 2 /nobreak > NUL & b.bat\r', build_tab)
	end )


---- Output rewriting (conceal) ------------------------

-- text filtering example: replace 'uint8_t' with 'u8'
-- (unless the cursor is on the same line).
-- In this example, use the default "conceal" colors that
-- just so happen to match my vimrc :high Conceal.
-- Note: the 'true' means that 'u8' will actually be 'u8     '.
--       Since vim doesn't know about this on-the-fly rewrite,
--       the UI gets all messed up; hence, make sure we pad to
--       the same length.
terminal.add_filter('uint8_t' , 'u8' , vim_tab,
					terminal.filter_color_front, terminal.filter_color_back,
					true)

-- text filtering example: keep the text, but change
-- the colors, to make LOG and ERR pop more.
-- Note: these colors are SDR for now.
terminal.add_filter('LOG', 'LOG', build_tab,
					hex_color(0.8, 0.8, 0.1), '0xFF000000')
-- get fancy. double wide characters are supported.
-- Note: filters stop at the first match.
terminal.add_filter('ERR', '  ', build_tab,
					hex_color(1.0, 0.0, 0.0), '0xFF000000')

-- example binding to toggle all filters so we can see ground truth
do
	local filters_enabled = true
	terminal.map_key('<C-S-f>', function()
		filters_enabled = not filters_enabled
		terminal.set_filters_enabled(filters_enabled)  -- global setting
	end)
end


---- Changing fonts ------------------------

-- font changing example: comments use highlight guifg=0x89898c,
-- the next line is how you write "when the foreground uses this
-- color, use font 1" (ie. the second font in config.fonts)
terminal.set_tab_color_font(0, true, hex_color(0x89/255, 0x89/255, 0x8c/255), 1)
-- same, but watch for a background color of 0x202040, and use font 3:
terminal.set_tab_color_font(0, false, hex_color(0x20/255, 0x20/255, 0x40/255), 3)


---- HDR boosts ------------------------

-- The terminal is still SDR, so to get HDR, we use a sort-of palette:
-- like with fonts, if a color matches a key, then it's replaced wholesale
-- by new (HDR) R, G, B values.
--
-- For instance, with this vimrc...
--
--      highlight search guifg=0xffff80
--
-- ... the next line will render search results in HDR rgb(5, 5, 2.5), ie.
--     about 5 times brighter than normal SDR "white".
--     HDR (1,1,1) is automatically calibrated to match SDR pure white on the
--     brightest monitor.
terminal.set_tab_remap_color(0,               -- terminal ID, 0 == current
							true,             -- check if the foreground matches..
							hex_color(0xff/255, 0xff/255, 0x80/255), -- .. this color,
							{ 5, 5, 2.5, 1 }  -- if so use this as foreground color
							)   -- optional 5th param changes background color



-- launch vim
terminal.send("nvim.exe -S workspace.vim\r", vim_tab)


-- change the background every 5 minutes
do
	local images = {
		'Pictures/wallpaper1.jpg',
		'Pictures/wallpaper2.png',
		'Pictures/wallpaper3.png',
	}
	local index = 1
	function set_wallpaper()
		terminal.set_tab_background_image(vim_tab, images[index])
		if index == #images then
			index = 1
		else
			index = index + 1
		end
		terminal.set_timer(5 * 60, set_wallpaper)
	end
	set_wallpaper()
end

